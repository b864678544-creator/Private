"""Рисует картинку-проверку: кадры с наложенными метками.
Смотрите, совпадает ли стрелка с тем, куда вы реально вели джойстик.

Запуск:  python preview.py sessions/<имя_записи>
"""
import argparse
import os
import random

import cv2
import numpy as np


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("session")
    ap.add_argument("--n", type=int, default=12)
    args = ap.parse_args()

    lab = np.load(os.path.join(args.session, "labels.npz"))
    idx, y = lab["idx"], lab["y"]
    active = [k for k in range(len(idx)) if abs(y[k, 0]) + abs(y[k, 1]) > 0 or y[k, 4] > 0]
    pool = active if len(active) >= args.n else list(range(len(idx)))
    random.seed(1)
    picks = sorted(random.sample(pool, min(args.n, len(pool))))

    tiles = []
    for k in picks:
        img = cv2.imread(os.path.join(args.session, "frames", f"{int(idx[k]):07d}.jpg"))
        img = cv2.resize(img, None, fx=3, fy=3, interpolation=cv2.INTER_NEAREST)
        h, w = img.shape[:2]
        c = (w // 2, h // 2)
        mx, my = float(y[k, 0]), float(y[k, 1])
        if abs(mx) + abs(my) > 0:
            cv2.arrowedLine(img, c, (int(c[0] + mx * 120), int(c[1] + my * 120)), (0, 255, 255), 3)
        if y[k, 7] > 0:
            cv2.arrowedLine(img, c, (int(c[0] + y[k, 2] * 120), int(c[1] + y[k, 3] * 120)), (0, 0, 255), 3)
        txt = " ".join(n for n, v in (("ATK", y[k, 4]), ("SUPER", y[k, 5]), ("GADGET", y[k, 6])) if v > 0)
        cv2.putText(img, txt or "-", (8, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        tiles.append(img)
    while len(tiles) % 3:
        tiles.append(np.zeros_like(tiles[0]))
    rows = [np.hstack(tiles[i:i + 3]) for i in range(0, len(tiles), 3)]
    out = os.path.join(args.session, "preview.jpg")
    cv2.imwrite(out, np.vstack(rows), [cv2.IMWRITE_JPEG_QUALITY, 85])
    print("Сохранено:", out)
    print("Жёлтая стрелка = куда вы вели джойстик, красная = куда целились, зелёный текст = нажатые кнопки.")


if __name__ == "__main__":
    main()
