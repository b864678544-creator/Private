"""Превращает записи в обучающие метки: для каждого кадра — что нажимал игрок.

Запуск:  python make_dataset.py sessions
Метки (8 чисел): move_x, move_y, aim_x, aim_y, attack, super, gadget, aim_active
"""
import argparse
import bisect
import csv
import json
import math
import os

import numpy as np

from common import find_sessions, load_layout


def load_touch_events(path):
    """Читает касания и для каждого запоминает, где оно началось."""
    times, states = [], []
    active_start = {}
    if not os.path.exists(path):
        return times, states
    with open(path, encoding="utf-8") as f:
        for line in f:
            ev = json.loads(line)
            ids_now = {t["id"] for t in ev["touches"]}
            for tid in list(active_start):
                if tid not in ids_now:
                    del active_start[tid]
            cur = []
            for t in ev["touches"]:
                if t["id"] not in active_start:
                    active_start[t["id"]] = (t["x"], t["y"])
                sx, sy = active_start[t["id"]]
                cur.append((t["x"], t["y"], sx, sy))
            times.append(ev["t"])
            states.append(cur)
    return times, states


def label_for(touches, L):
    asp = L["aspect"]
    move = [0.0, 0.0]
    aim = [0.0, 0.0]
    atk = sup = gad = aim_active = 0.0
    buttons = {"attack": L["attack"], "super": L["super"], "gadget": L["gadget"]}
    for x, y, sx, sy in touches:
        if sx < L["move_zone_max_x"]:
            dx = (x - L["joystick"][0]) * asp / L["joystick_radius"]
            dy = (y - L["joystick"][1]) / L["joystick_radius"]
            n = math.hypot(dx, dy)
            if n >= L["deadzone"]:
                k = 1.0 / max(n, 1.0)
                move = [dx * k, dy * k]
            continue
        best, bd = None, 1e9
        for name, (bx, by) in buttons.items():
            d = math.hypot((sx - bx) * asp, sy - by)
            if d < bd:
                best, bd = name, d
        rad = L["attack_radius"] if best == "attack" else L["button_radius"]
        if bd > rad * 1.6:
            continue
        if best == "attack":
            atk = 1.0
            ax = (x - L["attack"][0]) * asp / L["attack_radius"]
            ay = (y - L["attack"][1]) / L["attack_radius"]
            n = math.hypot(ax, ay)
            if n > 0.3:
                aim = [ax / n, ay / n]
                aim_active = 1.0
        elif best == "super":
            sup = 1.0
        else:
            gad = 1.0
    return [move[0], move[1], aim[0], aim[1], atk, sup, gad, aim_active]


def process(sd, L, lead):
    frames = []
    with open(os.path.join(sd, "frames.csv")) as f:
        for row in csv.reader(f):
            if len(row) == 2:
                frames.append((int(row[0]), float(row[1])))
    times, states = load_touch_events(os.path.join(sd, "touches.jsonl"))
    idx, ys = [], []
    for i, t in frames:
        j = bisect.bisect_right(times, t + lead) - 1
        touches = states[j] if j >= 0 else []
        idx.append(i)
        ys.append(label_for(touches, L))
    y = np.array(ys, np.float32)
    np.savez_compressed(os.path.join(sd, "labels.npz"), idx=np.array(idx, np.int32), y=y)
    n = max(len(y), 1)
    print(f"{sd}: кадров {len(y)} | движение {np.mean(np.hypot(y[:,0], y[:,1]) > 0):.0%} | "
          f"атака {y[:,4].mean():.0%} | супер {y[:,5].mean():.1%} | "
          f"гаджет {y[:,6].mean():.1%} | прицел {y[:,7].mean():.0%}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("paths", nargs="+")
    ap.add_argument("--lead", type=float, default=0.10,
                    help="берём нажатия через столько секунд после кадра (реакция игрока)")
    ap.add_argument("--layout", default="layout.json")
    args = ap.parse_args()
    L = load_layout(args.layout)
    sessions = find_sessions(args.paths)
    if not sessions:
        raise SystemExit("Не найдено ни одной записи (папка с frames.csv).")
    for sd in sessions:
        process(sd, L, args.lead)


if __name__ == "__main__":
    main()
