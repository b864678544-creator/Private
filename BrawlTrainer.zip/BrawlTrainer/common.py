"""Общие настройки и вспомогательные функции."""
import json
import os

FRAME_W, FRAME_H = 256, 112      # размер кадра для нейросети
FPS = 8                          # кадров в секунду при записи
STACK_STEPS = (0, 2, 4)          # какие кадры подаём: сейчас, 0.25 с назад, 0.5 с назад

DEFAULT_LAYOUT = {
    "aspect": 2.27,                       # ширина / высота экрана телефона
    "joystick": [0.147, 0.757],           # центр джойстика движения (доли экрана)
    "joystick_radius": 0.15,              # радиус в высотах экрана
    "attack": [0.843, 0.607],             # кнопка атаки
    "attack_radius": 0.13,
    "super": [0.714, 0.726],              # кнопка супера
    "gadget": [0.796, 0.880],             # кнопка гаджета
    "button_radius": 0.09,
    "move_zone_max_x": 0.40,              # левее этой границы касание = движение
    "deadzone": 0.12,                     # мёртвая зона джойстика (доля радиуса)
}


def load_layout(path="layout.json"):
    lay = dict(DEFAULT_LAYOUT)
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            lay.update(json.load(f))
    return lay


def find_sessions(paths):
    """Принимает папки сессий или папку, внутри которой лежат сессии."""
    out = []
    for p in paths:
        if os.path.exists(os.path.join(p, "frames.csv")):
            out.append(p)
        elif os.path.isdir(p):
            for name in sorted(os.listdir(p)):
                sd = os.path.join(p, name)
                if os.path.exists(os.path.join(sd, "frames.csv")):
                    out.append(sd)
    return out
