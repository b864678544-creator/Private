"""Запись игры: кадры экрана и касания пальцев с общей меткой времени.

Запуск:  python record.py
Остановка: Ctrl+C
"""
import argparse
import json
import os
import re
import subprocess
import sys
import threading
import time

import cv2
import numpy as np

from common import FRAME_H, FRAME_W, FPS

LINE_RE = re.compile(r"^\[\s*([\d.]+)\]\s+(?:(\S+):\s+)?(\w+)\s+(\w+)\s+(\w+)\s*$")


def adb(*args):
    return subprocess.run(["adb", *args], capture_output=True, text=True).stdout


def find_touch_device():
    """Ищем сенсорный экран и его максимальные координаты."""
    out = adb("shell", "getevent", "-lp")
    dev = None
    devs = {}
    for line in out.splitlines():
        m = re.match(r"add device \d+: (\S+)", line.strip())
        if m:
            dev = m.group(1)
            devs[dev] = {}
            continue
        if dev:
            m = re.search(r"ABS_MT_POSITION_([XY])\s*:.*max (\d+)", line)
            if m:
                devs[dev][m.group(1)] = int(m.group(2))
    for d, v in devs.items():
        if "X" in v and "Y" in v:
            return d, v["X"], v["Y"]
    raise SystemExit("Не найден сенсорный экран. Телефон подключён и отладка включена?")


def get_rotation():
    """1 = телефон повёрнут на 90°, 3 = на 270°. None, если не удалось определить."""
    out = adb("shell", "dumpsys", "input")
    m = re.search(r"SurfaceOrientation:\s*(\d)", out)
    return int(m.group(1)) if m else None


def to_land(u, v, rot):
    """Из координат сенсора (0..1, портрет) в координаты горизонтального экрана."""
    if rot == 1:
        x, y = v, 1.0 - u
    else:
        x, y = 1.0 - v, u
    return min(max(x, 0.0), 1.0), min(max(y, 0.0), 1.0)


class TouchParser:
    """Разбирает вывод `getevent -lt` в список активных касаний."""

    def __init__(self, maxx, maxy, rot):
        self.maxx, self.maxy, self.rot = maxx, maxy, rot
        self.slot = 0
        self.slots = {}

    def feed(self, line):
        m = LINE_RE.match(line.strip())
        if not m:
            return None
        typ, code, val = m.group(3), m.group(4), m.group(5)
        if typ == "EV_ABS":
            if code == "ABS_MT_SLOT":
                self.slot = int(val, 16)
            elif code == "ABS_MT_TRACKING_ID":
                if val.lower() == "ffffffff":
                    self.slots.pop(self.slot, None)
                else:
                    self.slots[self.slot] = {"id": int(val, 16), "x": None, "y": None}
            elif code in ("ABS_MT_POSITION_X", "ABS_MT_POSITION_Y"):
                s = self.slots.setdefault(self.slot, {"id": self.slot, "x": None, "y": None})
                s["x" if code.endswith("X") else "y"] = int(val, 16)
        elif typ == "EV_SYN" and code == "SYN_REPORT":
            snap = []
            for s in self.slots.values():
                if s["x"] is None or s["y"] is None:
                    continue
                x, y = to_land(s["x"] / self.maxx, s["y"] / self.maxy, self.rot)
                snap.append({"id": s["id"], "x": round(x, 4), "y": round(y, 4)})
            return snap
        return None


def touch_thread(dev, maxx, maxy, rot, path, stop, procs):
    parser = TouchParser(maxx, maxy, rot)
    p = subprocess.Popen(["adb", "shell", "getevent", "-lt", dev],
                         stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                         text=True, bufsize=1)
    procs.append(p)
    last = None
    with open(path, "w", encoding="utf-8") as f:
        for line in p.stdout:
            if stop.is_set():
                break
            snap = parser.feed(line)
            if snap is None:
                continue
            key = json.dumps(snap)
            if key == last:
                continue
            last = key
            f.write(json.dumps({"t": round(time.time(), 4), "touches": snap}) + "\n")
            f.flush()


def read_exact(stream, n):
    buf = b""
    while len(buf) < n:
        chunk = stream.read(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


def video_thread(outdir, latency, stop, procs, fake_source, counter):
    frames_dir = os.path.join(outdir, "frames")
    os.makedirs(frames_dir, exist_ok=True)
    nbytes = FRAME_W * FRAME_H * 3
    idx = 0
    with open(os.path.join(outdir, "frames.csv"), "w") as csv:
        while not stop.is_set():
            if fake_source:
                src_cmd = ["ffmpeg", "-loglevel", "error", "-re", "-i", fake_source,
                           "-an", "-c:v", "libx264", "-preset", "ultrafast",
                           "-tune", "zerolatency", "-f", "h264", "pipe:1"]
            else:
                # screenrecord сам останавливается через ~3 минуты, поэтому в цикле
                src_cmd = ["adb", "exec-out", "screenrecord", "--output-format=h264",
                           "--bit-rate", "6000000", "--time-limit", "170", "-"]
            sr = subprocess.Popen(src_cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
            ff = subprocess.Popen(
                ["ffmpeg", "-loglevel", "error", "-fflags", "nobuffer", "-flags", "low_delay",
                 "-probesize", "32768", "-analyzeduration", "0",
                 "-f", "h264", "-i", "pipe:0",
                 "-vf", f"fps={FPS},scale={FRAME_W}:{FRAME_H}:flags=area",
                 "-pix_fmt", "bgr24", "-f", "rawvideo", "pipe:1"],
                stdin=sr.stdout, stdout=subprocess.PIPE)
            sr.stdout.close()
            procs.extend([sr, ff])
            seg_t0 = None
            k = 0
            while not stop.is_set():
                buf = read_exact(ff.stdout, nbytes)
                if buf is None:
                    break
                if seg_t0 is None:
                    seg_t0 = time.time() - latency
                t = seg_t0 + k / FPS
                k += 1
                frame = np.frombuffer(buf, np.uint8).reshape(FRAME_H, FRAME_W, 3)
                cv2.imwrite(os.path.join(frames_dir, f"{idx:07d}.jpg"), frame,
                            [cv2.IMWRITE_JPEG_QUALITY, 92])
                csv.write(f"{idx},{t:.4f}\n")
                idx += 1
                counter[0] = idx
            for p in (sr, ff):
                try:
                    p.kill()
                except Exception:
                    pass
            if fake_source:
                break
        csv.flush()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=None, help="папка сессии (по умолчанию sessions/<время>)")
    ap.add_argument("--rotation", type=int, choices=[1, 3], default=None,
                    help="1 или 3, если автоопределение поворота не сработало")
    ap.add_argument("--latency", type=float, default=0.30,
                    help="задержка видео относительно касаний, сек")
    ap.add_argument("--seconds", type=float, default=0, help="остановиться через N секунд")
    ap.add_argument("--fake-source", default=None, help=argparse.SUPPRESS)
    args = ap.parse_args()

    out = args.out or os.path.join("sessions", time.strftime("%Y%m%d_%H%M%S"))
    os.makedirs(out, exist_ok=True)

    dev, maxx, maxy = find_touch_device()
    rot = args.rotation or get_rotation()
    if rot not in (1, 3):
        raise SystemExit("Поверните телефон в горизонталь (игра должна быть открыта) "
                         "или укажите --rotation 1 либо --rotation 3.")
    print(f"Сенсор: {dev} ({maxx}x{maxy}), поворот: {rot}")
    with open(os.path.join(out, "meta.json"), "w", encoding="utf-8") as f:
        json.dump({"device": dev, "maxx": maxx, "maxy": maxy, "rotation": rot,
                   "fps": FPS, "started": time.time()}, f)

    stop = threading.Event()
    procs = []
    counter = [0]
    t1 = threading.Thread(target=touch_thread, daemon=True,
                          args=(dev, maxx, maxy, rot, os.path.join(out, "touches.jsonl"), stop, procs))
    t2 = threading.Thread(target=video_thread, daemon=True,
                          args=(out, args.latency, stop, procs, args.fake_source, counter))
    t1.start()
    t2.start()
    print(f"Запись идёт -> {out}\nИграйте. Остановить: Ctrl+C")
    started = time.time()
    try:
        while t2.is_alive():
            time.sleep(1)
            print(f"\r  кадров: {counter[0]}  время: {int(time.time() - started)} с   ",
                  end="", flush=True)
            if args.seconds and time.time() - started >= args.seconds:
                break
    except KeyboardInterrupt:
        pass
    stop.set()
    for p in procs:
        try:
            p.kill()
        except Exception:
            pass
    time.sleep(0.5)
    print(f"\nГотово. Кадров: {counter[0]}. Папка: {out}")


if __name__ == "__main__":
    main()
