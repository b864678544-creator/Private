"""Обучение нейросети по вашей игре и экспорт в policy.tflite.

Запуск:  python train.py sessions
"""
import argparse
import json
import os

import cv2
import numpy as np

from common import FRAME_H, FRAME_W, STACK_STEPS, find_sessions


def load_all(sessions, max_frames):
    total = 0
    for sd in sessions:
        total += len(np.load(os.path.join(sd, "labels.npz"))["idx"])
    total = min(total, max_frames)
    X = np.zeros((total, FRAME_H, FRAME_W, 3), np.uint8)
    Y = np.zeros((total, 8), np.float32)
    first = np.zeros(total, np.int32)
    pos = 0
    for sd in sessions:
        lab = np.load(os.path.join(sd, "labels.npz"))
        start = pos
        for i, yy in zip(lab["idx"], lab["y"]):
            if pos >= total:
                break
            img = cv2.imread(os.path.join(sd, "frames", f"{int(i):07d}.jpg"))
            if img is None:
                continue
            X[pos] = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            Y[pos] = yy
            first[pos] = start
            pos += 1
    return X[:pos], Y[:pos], first[:pos]


def stack(X, first, i):
    parts = [X[max(first[i], i - s)] for s in STACK_STEPS]
    return np.concatenate(parts, axis=-1)


def batches(X, Y, first, idxs, batch, augment):
    rng = np.random.default_rng()
    while True:
        sel = rng.choice(idxs, batch)
        xb = np.stack([stack(X, first, i) for i in sel]).astype(np.float32)
        if augment:
            xb = xb * rng.uniform(0.85, 1.15, (batch, 1, 1, 1)) + rng.normal(0, 4, xb.shape)
            xb = np.clip(xb, 0, 255).astype(np.float32)
        yield xb, Y[sel]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("paths", nargs="+")
    ap.add_argument("--epochs", type=int, default=20)
    ap.add_argument("--batch", type=int, default=64)
    ap.add_argument("--max-frames", type=int, default=40000)
    args = ap.parse_args()

    import tensorflow as tf
    from tensorflow import keras
    from tensorflow.keras import layers

    sessions = find_sessions(args.paths)
    if not sessions:
        raise SystemExit("Не найдено записей. Сначала запустите make_dataset.py")
    print("Загружаю кадры...")
    X, Y, first = load_all(sessions, args.max_frames)
    n = len(X)
    print(f"Кадров: {n}")
    if n < 2000:
        print("ВНИМАНИЕ: данных мало (<2000 кадров ≈ 4 минуты). Результат будет слабым.")

    split = int(n * 0.9)
    train_idx = np.arange(0, split)
    val_idx = np.arange(split, n)
    step = max(1, len(val_idx) // 1500)
    val_sel = val_idx[::step]
    Xv = np.stack([stack(X, first, i) for i in val_sel]).astype(np.float32)
    Yv = Y[val_sel]

    def build_model():
        inp = keras.Input((FRAME_H, FRAME_W, 3 * len(STACK_STEPS)))
        x = layers.Rescaling(1 / 255.0)(inp)
        for f, k in [(24, 5), (32, 3), (48, 3), (64, 3), (96, 3)]:
            x = layers.Conv2D(f, k, strides=2, padding="same", activation="relu")(x)
        x = layers.Flatten()(x)
        x = layers.Dropout(0.3)(x)
        x = layers.Dense(128, activation="relu")(x)
        cont = layers.Dense(4, activation="tanh")(x)      # move_x, move_y, aim_x, aim_y
        btn = layers.Dense(4, activation="sigmoid")(x)    # attack, super, gadget, aim_active
        return keras.Model(inp, layers.Concatenate()([cont, btn]))

    def policy_loss(y_true, y_pred):
        mv = tf.reduce_mean(tf.square(y_true[:, 0:2] - y_pred[:, 0:2]), axis=1)
        am = tf.reduce_mean(tf.square(y_true[:, 2:4] - y_pred[:, 2:4]), axis=1) * y_true[:, 7]
        bt = tf.reduce_mean(
            keras.losses.binary_crossentropy(y_true[:, 4:8, None], y_pred[:, 4:8, None]), axis=1)
        return tf.reduce_mean(2.0 * mv + am + bt)

    model = build_model()
    model.compile(optimizer=keras.optimizers.Adam(1e-3), loss=policy_loss)
    steps = max(50, min(500, len(train_idx) // args.batch))
    model.fit(
        batches(X, Y, first, train_idx, args.batch, True),
        steps_per_epoch=steps, epochs=args.epochs,
        validation_data=(Xv, Yv),
        callbacks=[keras.callbacks.ModelCheckpoint("best.keras", save_best_only=True,
                                                   monitor="val_loss")],
    )

    best = keras.models.load_model("best.keras", compile=False)
    try:
        tflite = tf.lite.TFLiteConverter.from_keras_model(best).convert()
    except Exception as e:
        print("Прямой экспорт не удался, пробую через SavedModel:", e)
        best.export("saved_policy")
        tflite = tf.lite.TFLiteConverter.from_saved_model("saved_policy").convert()
    with open("policy.tflite", "wb") as f:
        f.write(tflite)
    with open("policy_meta.json", "w", encoding="utf-8") as f:
        json.dump({
            "input": [1, FRAME_H, FRAME_W, 3 * len(STACK_STEPS)],
            "input_range": "0..255, RGB, три кадра подряд по каналам",
            "stack_steps": list(STACK_STEPS), "fps": 8,
            "output": ["move_x", "move_y", "aim_x", "aim_y",
                       "attack", "super", "gadget", "aim_active"],
        }, f, ensure_ascii=False, indent=2)
    print("\nГотово: policy.tflite и policy_meta.json — скопируйте их на телефон.")


if __name__ == "__main__":
    main()
