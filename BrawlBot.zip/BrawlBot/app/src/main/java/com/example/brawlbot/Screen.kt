package com.example.brawlbot

import android.content.Context
import android.util.DisplayMetrics
import android.view.WindowManager

object Screen {
    /** Размер экрана в горизонтальной ориентации (как в игре): (ширина, высота). */
    fun landscape(ctx: Context): Pair<Int, Int> {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        return Pair(maxOf(dm.widthPixels, dm.heightPixels), minOf(dm.widthPixels, dm.heightPixels))
    }
}
