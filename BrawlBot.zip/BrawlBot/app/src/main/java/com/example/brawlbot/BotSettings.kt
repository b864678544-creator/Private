package com.example.brawlbot

import android.content.Context

/** Настройки ручного прицела (для Пайпер и других бойцов, где автоприцел не подходит). */
object BotSettings {
    @Volatile var aimMode = false
    /** Скорость снаряда в высотах экрана в секунду. Меньше значение = больше упреждение. */
    @Volatile var projSpeed = 1.6f
    /** Дальность стрельбы в высотах экрана. */
    @Volatile var range = 0.40f
    /** Режим Бравлбол: идти к воротам врага, бить по воротам, подбирать мяч. */
    @Volatile var ballMode = false
    /** С какого расстояния бить по воротам (в высотах экрана). */
    @Volatile var kickRange = 0.60f
    /** Режим Столкновение: бежать от газа, подбирать кубки там, где пропала цель. */
    @Volatile var showdownMode = false

    private var loaded = false

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        val sp = ctx.getSharedPreferences("brawlbot", Context.MODE_PRIVATE)
        aimMode = sp.getBoolean("aim", false)
        projSpeed = sp.getFloat("proj", 1.6f)
        range = sp.getFloat("range", 0.40f)
        ballMode = sp.getBoolean("ball", false)
        kickRange = sp.getFloat("kick", 0.60f)
        showdownMode = sp.getBoolean("showdown", false)
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences("brawlbot", Context.MODE_PRIVATE).edit()
            .putBoolean("aim", aimMode)
            .putFloat("proj", projSpeed)
            .putFloat("range", range)
            .putBoolean("ball", ballMode)
            .putFloat("kick", kickRange)
            .putBoolean("showdown", showdownMode)
            .apply()
    }
}
