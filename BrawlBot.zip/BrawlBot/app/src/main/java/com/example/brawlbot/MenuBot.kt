package com.example.brawlbot

import android.content.Context
import android.graphics.Rect

data class OcrLine(val text: String, val box: Rect)

/**
 * Автоменю: по тексту на экране (OCR) находит кнопки и нажимает их.
 * Цикл: лобби -> список бойцов -> карточка бойца (читаем трофеи, SELECT) -> лобби -> PLAY ->
 * матч -> результат (читаем +N) -> PLAY AGAIN ... пока не достигнута цель, потом следующий боец.
 */
object MenuBot {

    data class Target(val name: String, var goal: Int, var cur: Int = -1, var done: Boolean = false)

    val targets = ArrayList<Target>()
    @Volatile var enabled = false
    @Volatile var status = ""

    private class L(val n: String, val box: Rect, val raw: String)

    private var lastMenuSeen = 0L
    private var pauseUntil = 0L
    private var cooldownUntil = 0L
    private var active: Target? = null
    private var resultCounted = false
    private var notResultSince = 0L
    private var matchesSinceSync = 0
    private var listSwipes = 0
    private var selectTaps = 0
    private var loaded = false

    private val deltaRe = Regex("([+\\-−–])\\s*(\\d{1,2})")
    private val trophyRe = Regex("(\\d{1,4})\\s*/\\s*(\\d{2,4})")

    /** true, пока бот находится в меню — боевую логику в это время ставим на паузу. */
    fun inMenu(now: Long): Boolean = enabled && (now - lastMenuSeen < 2500 || now < pauseUntil)

    fun desired(): Target? = targets.firstOrNull { !it.done }

    fun resetProgress(ctx: Context) {
        for (t in targets) { t.done = false; t.cur = -1 }
        active = null
        matchesSinceSync = 0
        save(ctx)
    }

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        val sp = ctx.getSharedPreferences("brawlbot", Context.MODE_PRIVATE)
        enabled = sp.getBoolean("enabled", false)
        val raw = sp.getString("targets", "") ?: ""
        targets.clear()
        for (item in raw.split(";")) {
            val p = item.split("|")
            if (p.size == 4) {
                val goal = p[1].toIntOrNull() ?: continue
                targets.add(Target(p[0], goal, p[2].toIntOrNull() ?: -1, p[3] == "1"))
            }
        }
    }

    fun save(ctx: Context) {
        val sp = ctx.getSharedPreferences("brawlbot", Context.MODE_PRIVATE)
        sp.edit()
            .putBoolean("enabled", enabled)
            .putString("targets", targets.joinToString(";") {
                "${it.name}|${it.goal}|${it.cur}|${if (it.done) 1 else 0}"
            })
            .apply()
    }

    private fun n(s: String) = s.uppercase().filter { it.isLetterOrDigit() || it == '+' || it == '-' || it == '/' }
    private fun nameKey(s: String) = s.uppercase().filter { it.isLetter() }
    private fun matchName(a: String, key: String) = if (key.length >= 4) a.contains(key) else a == key

    private fun parseDelta(ls: List<L>, w: Int, h: Int): Int? {
        for (l in ls) {
            if (l.box.centerX() > w * 0.45 || l.box.centerY() > h * 0.35) continue
            val m = deltaRe.find(l.raw) ?: continue
            val v = m.groupValues[2].toIntOrNull() ?: continue
            return if (m.groupValues[1] == "+") v else -v
        }
        return null
    }

    private fun parseTrophies(ls: List<L>, w: Int, h: Int): Int? {
        for (l in ls) {
            if (l.box.centerX() > w * 0.4 || l.box.centerY() < h * 0.3 || l.box.centerY() > h * 0.6) continue
            val m = trophyRe.find(l.raw) ?: continue
            return m.groupValues[1].toIntOrNull()
        }
        return null
    }

    /** Вызывается после каждого распознавания текста на кадре размером w x h. */
    fun onOcr(lines: List<OcrLine>, w: Int, h: Int, now: Long) {
        if (!enabled) return
        val svc = BotAccessibilityService.instance
        if (svc == null) { status = "включите спец. возможности"; return }

        val ls = lines.map { L(n(it.text), it.box, it.text) }
        fun has(k: String) = ls.any { it.n.contains(k) }
        fun exact(k: String) = ls.firstOrNull { it.n == k }
        fun cont(k: String) = ls.firstOrNull { it.n.contains(k) }

        fun tapBox(b: Rect): Boolean {
            val (sw, sh) = Screen.landscape(svc)
            return svc.tap(b.exactCenterX() * sw / w, b.exactCenterY() * sh / h)
        }
        fun tapFrac(fx: Float, fy: Float): Boolean {
            val (sw, sh) = Screen.landscape(svc)
            return svc.tap(sw * fx, sh * fy)
        }
        fun swipe(fx1: Float, fx2: Float): Boolean {
            val (sw, sh) = Screen.landscape(svc)
            return svc.swipe(sw * fx1, sh * 0.55f, sw * fx2, sh * 0.55f, 450)
        }
        fun back(): Boolean = tapFrac(0.088f, 0.044f)

        val playBtn = ls.firstOrNull {
            it.n == "PLAY" && it.box.centerX() > w * 0.7 && it.box.centerY() > h * 0.75
        }
        val selLine = ls.firstOrNull { it.n == "SELECT" || it.n == "SELECTED" }
        val isResult = has("VICTORY") || has("DEFEAT")
        val isHighlight = has("GAMEHIGHLIGHT")
        val isList = has("BRAWLERSTOUNLOCK") || (has("RARITY") && has("SEARCH"))
        val playAgain = cont("PLAYAGAIN")
        val proceed = exact("PROCEED")
        val exit = exact("EXIT")

        if (isResult || isHighlight || selLine != null || isList || playBtn != null ||
            playAgain != null || proceed != null) {
            lastMenuSeen = now
        }

        if (now < cooldownUntil) return

        // ---------- Экран результата ----------
        if (isResult) {
            notResultSince = 0L
            val a = active
            if (!resultCounted) {
                resultCounted = true
                matchesSinceSync++
                val delta = parseDelta(ls, w, h)
                if (a != null && delta != null && a.cur >= 0) { a.cur += delta; save(svc) }
            }
            val reached = a == null || (a.cur >= 0 && a.cur >= a.goal) || matchesSinceSync >= 10
            if (reached) {
                status = "результат: выхожу в лобби"
                val b = proceed ?: exit
                if (b != null && tapBox(b.box)) { active = null; cooldownUntil = now + 2500 }
            } else {
                status = "${a?.name}: ${a?.cur}/${a?.goal}, играю ещё"
                if (playAgain != null && tapBox(playAgain.box)) {
                    cooldownUntil = now + 3000
                    pauseUntil = now + 12000
                }
            }
            return
        }
        if (notResultSince == 0L) notResultSince = now
        else if (now - notResultSince > 4000) resultCounted = false

        // ---------- Ролик «Game highlight» ----------
        if (isHighlight) {
            status = "пропускаю ролик"
            if (proceed != null && tapBox(proceed.box)) cooldownUntil = now + 2000
            return
        }

        // ---------- Карточка бойца ----------
        if (selLine != null) {
            val d = desired()
            if (d == null) { status = "все цели достигнуты"; return }
            val key = nameKey(d.name)
            val nameOk = ls.any { nameKey(it.raw).contains(key) }
            if (!nameOk) {
                status = "не тот боец, назад"
                if (back()) cooldownUntil = now + 1500
                return
            }
            val cur = parseTrophies(ls, w, h)
            if (cur != null) { d.cur = cur; matchesSinceSync = 0; save(svc) }
            if (d.cur >= 0 && d.cur >= d.goal) {
                d.done = true; save(svc)
                status = "${d.name}: цель достигнута"
                if (back()) cooldownUntil = now + 1500
                return
            }
            if (selLine.n == "SELECTED") {
                active = d
                if (back()) cooldownUntil = now + 1500
                return
            }
            selectTaps++
            if (selectTaps > 3) {
                d.done = true; save(svc); selectTaps = 0
                status = "${d.name}: не удалось выбрать, пропускаю"
                if (back()) cooldownUntil = now + 1500
                return
            }
            status = "выбираю ${d.name} (${d.cur}/${d.goal})"
            if (tapBox(selLine.box)) { active = d; cooldownUntil = now + 2500 }
            return
        }

        // ---------- Список бойцов ----------
        if (isList) {
            val d = desired()
            if (d == null) { status = "все цели достигнуты"; return }
            val key = nameKey(d.name)
            val hit = ls.firstOrNull { it.box.centerY() > h * 0.15 && matchName(nameKey(it.raw), key) }
            if (hit != null) {
                status = "нашёл ${d.name}"
                if (tapBox(hit.box)) { cooldownUntil = now + 2000; listSwipes = 0 }
            } else {
                listSwipes++
                status = "ищу ${d.name} (прокрутка $listSwipes)"
                if (listSwipes <= 6) swipe(0.75f, 0.25f)
                else if (listSwipes <= 12) swipe(0.25f, 0.75f)
                else {
                    d.done = true; save(svc); listSwipes = 0
                    status = "${d.name} не найден, пропускаю"
                }
                cooldownUntil = now + 1500
            }
            return
        }

        // ---------- Лобби ----------
        if (playBtn != null) {
            selectTaps = 0
            val d = desired()
            if (d == null) { status = "все цели достигнуты"; return }
            if (active === d) {
                status = "играю: ${d.name}"
                if (tapBox(playBtn.box)) {
                    cooldownUntil = now + 4000
                    pauseUntil = now + 14000
                }
            } else {
                status = "открываю список бойцов"
                val b = ls.firstOrNull {
                    it.n == "BRAWLERS" && it.box.centerX() < w * 0.25 &&
                        it.box.centerY() > h * 0.35 && it.box.centerY() < h * 0.65
                }
                val ok = if (b != null) tapBox(b.box) else tapFrac(0.095f, 0.46f)
                if (ok) { cooldownUntil = now + 2000; listSwipes = 0 }
            }
            return
        }

        status = "в матче / жду"
    }
}
