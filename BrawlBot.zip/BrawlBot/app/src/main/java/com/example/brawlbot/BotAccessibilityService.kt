package com.example.brawlbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class BotAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: BotAccessibilityService? = null
    }

    @Volatile private var busy = false

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun perform(a: BotAction) {
        if (busy) return
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()

        // Позиции элементов управления (доли экрана, ландшафт) — подгоните под себя
        val joyX = w * 0.15f
        val joyY = h * 0.72f
        val joyR = w * 0.07f
        val atkX = w * 0.86f
        val atkY = h * 0.74f

        val builder = GestureDescription.Builder()

        if (a.dx != 0f || a.dy != 0f) {
            val p = Path().apply {
                moveTo(joyX, joyY)
                lineTo(joyX + a.dx * joyR, joyY + a.dy * joyR)
            }
            builder.addStroke(GestureDescription.StrokeDescription(p, 0, 200))
        }
        if (a.attack) {
            val p = Path().apply { moveTo(atkX, atkY) }
            builder.addStroke(GestureDescription.StrokeDescription(p, 0, 80))
        }

        try {
            busy = true
            val ok = dispatchGesture(builder.build(), object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { busy = false }
                override fun onCancelled(g: GestureDescription?) { busy = false }
            }, null)
            if (!ok) busy = false
        } catch (e: Exception) {
            busy = false
        }
    }
}
