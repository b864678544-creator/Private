package com.example.brawlbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class BotAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: BotAccessibilityService? = null
    }

    @Volatile private var busy = false
    @Volatile private var pendingSuper = false
    @Volatile private var pendingGadget = false
    @Volatile private var pendingAim: FloatArray? = null
    @Volatile private var pendingAimAt = 0L

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun perform(a: BotAction) {
        if (a.superBtn) pendingSuper = true
        if (a.gadget) pendingGadget = true
        if (a.aim) { pendingAim = floatArrayOf(a.aimDx, a.aimDy); pendingAimAt = System.currentTimeMillis() }
        if (busy) return
        val (sw, sh) = Screen.landscape(this)
        val w = sw.toFloat()
        val h = sh.toFloat()

        // Позиции элементов управления (доли экрана, ландшафт) — подгоните под себя
        val joyX = w * 0.147f
        val joyY = h * 0.757f
        val joyR = w * 0.05f
        val atkX = w * 0.843f
        val atkY = h * 0.607f
        val supX = w * 0.714f
        val supY = h * 0.726f
        val gadX = w * 0.796f
        val gadY = h * 0.880f

        val builder = GestureDescription.Builder()
        var strokes = 0

        if (a.dx != 0f || a.dy != 0f) {
            val p = Path().apply {
                moveTo(joyX, joyY)
                lineTo(joyX + a.dx * joyR, joyY + a.dy * joyR)
            }
            builder.addStroke(GestureDescription.StrokeDescription(p, 0, 200))
            strokes++
        }
        val aimVec = pendingAim
        if (aimVec != null) {
            pendingAim = null
            if (System.currentTimeMillis() - pendingAimAt < 500) {
                // тянем кнопку атаки в сторону цели и отпускаем — выстрел
                val r = w * 0.05f
                val p = Path().apply {
                    moveTo(atkX, atkY)
                    lineTo(atkX + aimVec[0] * r, atkY + aimVec[1] * r)
                }
                builder.addStroke(GestureDescription.StrokeDescription(p, 0, 150))
                strokes++
            }
        } else if (a.attack) {
            val p = Path().apply { moveTo(atkX, atkY) }
            builder.addStroke(GestureDescription.StrokeDescription(p, 0, 80))
            strokes++
        }
        if (pendingSuper) {
            pendingSuper = false
            val p = Path().apply { moveTo(supX, supY) }
            builder.addStroke(GestureDescription.StrokeDescription(p, 0, 80))
            strokes++
        }
        if (pendingGadget) {
            pendingGadget = false
            val p = Path().apply { moveTo(gadX, gadY) }
            builder.addStroke(GestureDescription.StrokeDescription(p, 0, 80))
            strokes++
        }
        if (strokes == 0) return

        try {
            busy = true
            val ok = dispatchGesture(builder.build(), object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { busy = false }
                override fun onCancelled(g: GestureDescription?) { busy = false }
            }, null)
            if (!ok) busy = false
        } catch (e: Exception) {
            busy = false
        }
    }

    fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return singleGesture(p, 80)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long): Boolean {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        return singleGesture(p, durationMs)
    }

    private fun singleGesture(p: Path, durationMs: Long): Boolean {
        if (busy) return false
        return try {
            busy = true
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(p, 0, durationMs))
                .build()
            val ok = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(gd: GestureDescription?) { busy = false }
                override fun onCancelled(gd: GestureDescription?) { busy = false }
            }, null)
            if (!ok) busy = false
            ok
        } catch (e: Exception) {
            busy = false
            false
        }
    }
}
