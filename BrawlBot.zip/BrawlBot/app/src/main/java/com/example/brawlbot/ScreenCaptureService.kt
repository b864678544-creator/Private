package com.example.brawlbot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class ScreenCaptureService : Service() {

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var lastRun = 0L
    private var lastStatus = 0L
    private var lastOcr = 0L
    @Volatile private var ocrBusy = false

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("code", 0) ?: return START_NOT_STICKY
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY

        MenuBot.load(this)
        Settings.load(this)
        startAsForeground()

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        thread = HandlerThread("capture").also { it.start() }
        val handler = Handler(thread!!.looper)

        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        // Масштаб 0.5: достаточно для распознавания текста и быстро для анализа боя
        val dm = resources.displayMetrics
        val (sw, sh) = Screen.landscape(this)
        val scale = 0.5f
        val w = (sw * scale).toInt()
        val h = (sh * scale).toInt()

        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        display = projection!!.createVirtualDisplay(
            "bot", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, handler
        )

        reader!!.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = System.currentTimeMillis()
                if (now - lastRun < 120) return@setOnImageAvailableListener
                lastRun = now

                if (MenuBot.enabled && !ocrBusy && now - lastOcr > 1500) {
                    lastOcr = now
                    runOcr(img)
                }

                val plane = img.planes[0]
                val action = Detector.analyze(
                    plane.buffer, img.width, img.height,
                    plane.rowStride, plane.pixelStride, now
                )
                // В меню боевую логику не запускаем
                if (!MenuBot.inMenu(now)) {
                    BotAccessibilityService.instance?.perform(action)
                }
                if (now - lastStatus > 1000) {
                    lastStatus = now
                    val a11y = if (BotAccessibilityService.instance != null) "вкл" else "ВЫКЛ"
                    val menu = if (MenuBot.enabled) " | меню: ${MenuBot.status}" else ""
                    updateStatus("Спец: $a11y | враги: ${action.enemies} | HP: ${action.hp}% | ${action.mode}$menu")
                }
            } finally {
                img.close()
            }
        }, handler)

        return START_NOT_STICKY
    }

    private fun runOcr(img: Image) {
        try {
            val plane = img.planes[0]
            val rowPadding = plane.rowStride - plane.pixelStride * img.width
            val bmp = Bitmap.createBitmap(
                img.width + rowPadding / plane.pixelStride, img.height, Bitmap.Config.ARGB_8888
            )
            bmp.copyPixelsFromBuffer(plane.buffer)
            val crop = Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
            bmp.recycle()
            val w = img.width
            val h = img.height
            ocrBusy = true
            recognizer.process(InputImage.fromBitmap(crop, 0))
                .addOnSuccessListener { res ->
                    val lines = ArrayList<OcrLine>()
                    for (b in res.textBlocks) for (l in b.lines) {
                        val bb = l.boundingBox ?: continue
                        lines.add(OcrLine(l.text, bb))
                    }
                    try {
                        MenuBot.onOcr(lines, w, h, System.currentTimeMillis())
                    } finally {
                        ocrBusy = false
                    }
                }
                .addOnFailureListener { ocrBusy = false }
        } catch (e: Exception) {
            ocrBusy = false
        }
    }

    private fun updateStatus(text: String) {
        val n = Notification.Builder(this, "bot")
            .setContentTitle("BrawlBot работает")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        getSystemService(NotificationManager::class.java).notify(1, n)
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("bot", "Bot", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "bot")
            .setContentTitle("BrawlBot работает")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    override fun onDestroy() {
        display?.release()
        reader?.close()
        projection?.stop()
        thread?.quitSafely()
        super.onDestroy()
    }
}
