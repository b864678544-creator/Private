package com.example.brawlbot

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var listView: TextView

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == RESULT_OK && r.data != null) {
                val i = Intent(this, ScreenCaptureService::class.java)
                    .putExtra("code", r.resultCode)
                    .putExtra("data", r.data)
                startForegroundService(i)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MenuBot.load(this)
        Settings.load(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(40, 40, 40, 40)
        }

        root.addView(TextView(this).apply {
            text = "1) Включите службу спец. возможностей\n2) (по желанию) заполните список бойцов и включите «Авто-меню»\n3) Нажмите «Старт» и откройте игру в лобби"
            textSize = 15f
        })
        root.addView(Button(this).apply {
            text = "1. Спец. возможности"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        // ---- Список бойцов ----
        root.addView(TextView(this).apply { text = "\nБойцы и цели по трофеям:"; textSize = 16f })
        listView = TextView(this).apply { textSize = 15f }
        root.addView(listView)

        val nameEdit = EditText(this).apply { hint = "Имя бойца как в игре (Shelly)" }
        val goalEdit = EditText(this).apply {
            hint = "До скольки трофеев (например 500)"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        root.addView(nameEdit)
        root.addView(goalEdit)
        root.addView(Button(this).apply {
            text = "Добавить в список"
            setOnClickListener {
                val name = nameEdit.text.toString().trim().replace("|", "").replace(";", "")
                val goal = goalEdit.text.toString().trim().toIntOrNull()
                if (name.isEmpty() || goal == null) {
                    Toast.makeText(this@MainActivity, "Введите имя и число", Toast.LENGTH_SHORT).show()
                } else {
                    MenuBot.targets.add(MenuBot.Target(name, goal))
                    MenuBot.save(this@MainActivity)
                    nameEdit.setText(""); goalEdit.setText("")
                    refresh()
                }
            }
        })
        root.addView(Button(this).apply {
            text = "Сбросить прогресс"
            setOnClickListener { MenuBot.resetProgress(this@MainActivity); refresh() }
        })
        root.addView(Button(this).apply {
            text = "Очистить список"
            setOnClickListener {
                MenuBot.targets.clear()
                MenuBot.save(this@MainActivity)
                refresh()
            }
        })
        root.addView(Switch(this).apply {
            text = "Авто-меню (выбор бойца, PLAY, PLAY AGAIN)  "
            isChecked = MenuBot.enabled
            setOnCheckedChangeListener { _, checked ->
                MenuBot.enabled = checked
                MenuBot.save(this@MainActivity)
            }
        })

        // ---- Ручной прицел ----
        root.addView(TextView(this).apply { text = "\nРучной прицел с упреждением (Пайпер и т.п.):"; textSize = 16f })
        root.addView(Switch(this).apply {
            text = "Включить ручной прицел  "
            isChecked = Settings.aimMode
            setOnCheckedChangeListener { _, checked ->
                Settings.aimMode = checked
                Settings.save(this@MainActivity)
            }
        })
        val speedEdit = EditText(this).apply {
            hint = "Скорость снаряда (по умолч. 1.6)"
            setText(Settings.projSpeed.toString())
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        val rangeEdit = EditText(this).apply {
            hint = "Дальность (по умолч. 0.40)"
            setText(Settings.range.toString())
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        root.addView(speedEdit)
        root.addView(rangeEdit)
        root.addView(Button(this).apply {
            text = "Сохранить настройки прицела"
            setOnClickListener {
                val sp = speedEdit.text.toString().replace(',', '.').toFloatOrNull()
                val rg = rangeEdit.text.toString().replace(',', '.').toFloatOrNull()
                if (sp == null || rg == null || sp <= 0f || rg <= 0f) {
                    Toast.makeText(this@MainActivity, "Введите числа больше нуля", Toast.LENGTH_SHORT).show()
                } else {
                    Settings.projSpeed = sp
                    Settings.range = rg
                    Settings.save(this@MainActivity)
                    Toast.makeText(this@MainActivity, "Сохранено", Toast.LENGTH_SHORT).show()
                }
            }
        })

        // ---- Бравлбол ----
        root.addView(TextView(this).apply { text = "\nРежим Бравлбол:"; textSize = 16f })
        root.addView(Switch(this).apply {
            text = "Бравлбол (ворота и мяч)  "
            isChecked = Settings.ballMode
            setOnCheckedChangeListener { _, checked ->
                Settings.ballMode = checked
                Settings.save(this@MainActivity)
            }
        })
        val kickEdit = EditText(this).apply {
            hint = "Дальность удара по воротам (по умолч. 0.60)"
            setText(Settings.kickRange.toString())
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        root.addView(kickEdit)
        root.addView(Button(this).apply {
            text = "Сохранить дальность удара"
            setOnClickListener {
                val k = kickEdit.text.toString().replace(',', '.').toFloatOrNull()
                if (k == null || k <= 0f) {
                    Toast.makeText(this@MainActivity, "Введите число больше нуля", Toast.LENGTH_SHORT).show()
                } else {
                    Settings.kickRange = k
                    Settings.save(this@MainActivity)
                    Toast.makeText(this@MainActivity, "Сохранено", Toast.LENGTH_SHORT).show()
                }
            }
        })

        // ---- Столкновение ----
        root.addView(TextView(this).apply { text = "\nРежим Столкновение:"; textSize = 16f })
        root.addView(Switch(this).apply {
            text = "Столкновение (газ и кубки)  "
            isChecked = Settings.showdownMode
            setOnCheckedChangeListener { _, checked ->
                Settings.showdownMode = checked
                Settings.save(this@MainActivity)
            }
        })

        // ---- Запуск ----
        root.addView(Button(this).apply {
            text = "2. Старт"
            setOnClickListener {
                val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projectionLauncher.launch(mpm.createScreenCaptureIntent())
            }
        })
        root.addView(Button(this).apply {
            text = "Стоп"
            setOnClickListener { stopService(Intent(this@MainActivity, ScreenCaptureService::class.java)) }
        })

        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        listView.text = if (MenuBot.targets.isEmpty()) {
            "(пусто)"
        } else {
            MenuBot.targets.joinToString("\n") {
                val cur = if (it.cur >= 0) it.cur.toString() else "?"
                "${if (it.done) "✓" else "•"} ${it.name}: $cur → ${it.goal}"
            }
        }
    }
}
