package com.example.brawlbot

import java.nio.ByteBuffer

/** Что бот решил сделать. dx, dy — направление движения (-1..1). */
data class BotAction(
    val dx: Float,
    val dy: Float,
    val attack: Boolean,
    val superBtn: Boolean = false,
    val gadget: Boolean = false,
    val count: Int = 0,      // красных пикселей (для отладки)
    val enemies: Int = 0,    // сколько врагов видно
    val hp: Int = 100,       // своё здоровье, %
    val mode: String = ""    // что делает бот (для уведомления)
)

/**
 * Бот на правилах:
 *  - ищет врагов по красным пятнам (перчатки, кольцо под врагом), группирует их и выбирает ближайшего;
 *  - читает своё здоровье по зелёной полоске над игроком (игрок = центр экрана);
 *  - уклоняется: ходит боком вокруг врага, а при получении урона резко меняет направление;
 *  - обходит препятствия: если экран не меняется, хотя бот идёт, — сворачивает в сторону;
 *  - при низком здоровье отступает; суперудар и гаджет — когда рядом несколько врагов.
 *
 * Чтобы заменить на нейросеть: подключите TensorFlow Lite и верните BotAction из модели.
 */
object Detector {

    private const val CELL = 8
    private const val MIN_CELL = 3
    private const val MIN_BLOB = 3
    private const val FP_W = 40
    private const val FP_H = 24

    // --- пороги, которые можно подстроить ---
    private const val LOW_HP = 0.35f          // ниже этого — отступаем
    private const val STUCK_DIFF = 1.5f       // меньше — экран «не меняется»
    private const val STUCK_FRAMES = 5        // сколько кадров подряд = застрял
    private const val FIGHT_DIST = 0.25f      // дистанция боя (доля высоты экрана)
    private const val SKILL_COOLDOWN = 5000L  // пауза между суперударом/гаджетом, мс

    private var prevFp: IntArray? = null
    private var prevHp = 1f
    private var hpRef = 0f
    private var strafeDir = 1
    private var strafeFlipAt = 0L
    private var dodgeUntil = 0L
    private var stuckCount = 0
    private var unstuckUntil = 0L
    private var unstuckDx = 0f
    private var unstuckDy = 0f
    private var lastDx = 0f
    private var lastDy = 0f
    private var lastSuper = 0L
    private var lastGadget = 0L
    private val rnd = java.util.Random()

    fun analyze(
        buf: ByteBuffer, w: Int, h: Int, rowStride: Int, pixelStride: Int, now: Long
    ): BotAction {

        // ---------- 1. Красные пятна -> сетка ----------
        val gw = w / CELL + 1
        val gh = h / CELL + 1
        val grid = IntArray(gw * gh)
        var total = 0
        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                val i = y * rowStride + x * pixelStride
                val r = buf.get(i).toInt() and 0xFF
                val g = buf.get(i + 1).toInt() and 0xFF
                val b = buf.get(i + 2).toInt() and 0xFF
                if (r > 200 && g < 70 && b < 70) {
                    grid[(y / CELL) * gw + (x / CELL)]++
                    total++
                }
                x += 2
            }
            y += 2
        }

        // ---------- 2. Пятна -> группы -> враги ----------
        val visited = BooleanArray(gw * gh)
        val stack = IntArray(gw * gh)
        val groups = ArrayList<FloatArray>() // [sumX, sumY, n]
        val mergeR = h * 0.14f
        for (start in grid.indices) {
            if (visited[start] || grid[start] < MIN_CELL) continue
            var sp = 0
            stack[sp++] = start
            visited[start] = true
            var sx = 0L
            var sy = 0L
            var cells = 0
            while (sp > 0) {
                val c = stack[--sp]
                val cx = c % gw
                val cy = c / gw
                sx += cx; sy += cy; cells++
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = cx + dx
                    val ny = cy + dy
                    if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue
                    val ni = ny * gw + nx
                    if (!visited[ni] && grid[ni] >= MIN_CELL) {
                        visited[ni] = true
                        stack[sp++] = ni
                    }
                }
            }
            if (cells < MIN_BLOB) continue
            val bx = (sx.toFloat() / cells + 0.5f) * CELL
            val by = (sy.toFloat() / cells + 0.5f) * CELL
            var merged = false
            for (g in groups) {
                val gx = g[0] / g[2]
                val gy = g[1] / g[2]
                if (kotlin.math.hypot(bx - gx, by - gy) < mergeR) {
                    g[0] += bx; g[1] += by; g[2] += 1f
                    merged = true
                    break
                }
            }
            if (!merged) groups.add(floatArrayOf(bx, by, 1f))
        }

        val cx0 = w / 2f
        val cy0 = h / 2f
        var bestDist = Float.MAX_VALUE
        var bestX = 0f
        var bestY = 0f
        var enemiesNear = 0
        for (g in groups) {
            val ex = g[0] / g[2]
            val ey = g[1] / g[2]
            val d = kotlin.math.hypot(ex - cx0, ey - cy0)
            if (d < bestDist) { bestDist = d; bestX = ex; bestY = ey }
            if (d < h * 0.45f) enemiesNear++
        }
        val hasEnemy = groups.isNotEmpty()

        // ---------- 3. Своё здоровье ----------
        val hpRead = readHp(buf, w, h, rowStride, pixelStride)
        val hp = if (hpRead < 0f) prevHp else hpRead
        val hpDrop = prevHp - hp > 0.03f
        prevHp = hp

        // ---------- 4. «Отпечаток» кадра для определения застревания ----------
        val fp = IntArray(FP_W * FP_H)
        for (gy in 0 until FP_H) {
            val py = ((gy + 0.5f) * h / FP_H).toInt().coerceIn(0, h - 1)
            for (gx in 0 until FP_W) {
                val px = ((gx + 0.5f) * w / FP_W).toInt().coerceIn(0, w - 1)
                fp[gy * FP_W + gx] = buf.get(py * rowStride + px * pixelStride + 1).toInt() and 0xFF
            }
        }
        val prev = prevFp
        var diff = 99f
        if (prev != null) {
            var s = 0L
            for (k in fp.indices) s += kotlin.math.abs(fp[k] - prev[k])
            diff = s.toFloat() / fp.size
        }
        prevFp = fp

        val wasMoving = lastDx != 0f || lastDy != 0f
        if (wasMoving && diff < STUCK_DIFF && now >= unstuckUntil) stuckCount++ else stuckCount = 0
        if (stuckCount >= STUCK_FRAMES) {
            stuckCount = 0
            unstuckUntil = now + 1000
            val sign = if (rnd.nextBoolean()) 1f else -1f
            unstuckDx = -lastDy * sign
            unstuckDy = lastDx * sign
            if (unstuckDx == 0f && unstuckDy == 0f) unstuckDx = sign
        }

        // ---------- 5. Уклонение: смена стороны ----------
        if (now >= strafeFlipAt) {
            strafeDir = -strafeDir
            strafeFlipAt = now + 700 + rnd.nextInt(500)
        }
        if (hpDrop) {
            strafeDir = -strafeDir
            dodgeUntil = now + 500
            strafeFlipAt = now + 1200
        }

        // ---------- 6. Решение ----------
        var dx = 0f
        var dy = 0f
        var attack = false
        var mode: String

        val vx = bestX - cx0
        val vy = bestY - cy0
        val dist = bestDist.coerceAtLeast(1f)
        val ux = if (hasEnemy) vx / dist else 0f
        val uy = if (hasEnemy) vy / dist else 0f
        val px = -uy * strafeDir // перпендикуляр (бок)
        val py = ux * strafeDir

        if (now < unstuckUntil) {
            dx = unstuckDx; dy = unstuckDy; attack = hasEnemy; mode = "обход препятствия"
        } else if (hasEnemy && hp < LOW_HP) {
            dx = -ux; dy = -uy; attack = true; mode = "отступление"
        } else if (!hasEnemy && hp < LOW_HP) {
            mode = "отдых"
        } else if (!hasEnemy) {
            dy = -1f; mode = "поиск"
        } else if (now < dodgeUntil) {
            dx = px; dy = py; attack = true; mode = "уклонение"
        } else if (dist >= h * FIGHT_DIST) {
            dx = ux + px * 0.35f; dy = uy + py * 0.35f; attack = true; mode = "сближение"
        } else {
            dx = px * 0.9f; dy = py * 0.9f
            if (dist < h * 0.12f) { dx -= ux * 0.6f; dy -= uy * 0.6f }
            attack = true; mode = "бой"
        }

        val len = kotlin.math.hypot(dx, dy)
        if (len > 1f) { dx /= len; dy /= len }

        // ---------- 7. Суперудар и гаджет ----------
        var sup = false
        var gad = false
        if (enemiesNear >= 2 && now - lastSuper > SKILL_COOLDOWN) {
            sup = true; lastSuper = now
        }
        if ((enemiesNear >= 2 || (enemiesNear >= 1 && hp < 0.6f)) && now - lastGadget > SKILL_COOLDOWN) {
            gad = true; lastGadget = now
        }

        lastDx = dx
        lastDy = dy
        return BotAction(
            dx, dy, attack, sup, gad,
            count = total, enemies = groups.size, hp = (hp * 100).toInt(), mode = mode
        )
    }

    /** Своё здоровье 0..1 по зелёной полоске над игроком, либо -1 если не нашли. */
    private fun readHp(buf: ByteBuffer, w: Int, h: Int, rowStride: Int, pixelStride: Int): Float {
        val cx = w / 2
        val half = (w * 0.035f).toInt().coerceAtLeast(6)
        val yA = (h * 0.40f).toInt()
        val yB = (h * 0.435f).toInt()
        var bestCount = 0
        var bestSpan = 0
        for (y in yA..yB) {
            var cnt = 0
            var minX = Int.MAX_VALUE
            var maxX = -1
            for (x in (cx - half)..(cx + half)) {
                if (x < 0 || x >= w || y < 0 || y >= h) continue
                val i = y * rowStride + x * pixelStride
                val r = buf.get(i).toInt() and 0xFF
                val g = buf.get(i + 1).toInt() and 0xFF
                val b = buf.get(i + 2).toInt() and 0xFF
                if (g > 170 && g - r > 40 && g - b > 50) {
                    cnt++
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                }
            }
            if (cnt > bestCount) { bestCount = cnt; bestSpan = maxX - minX + 1 }
        }
        if (bestCount < 4) return -1f
        if (hpRef == 0f) hpRef = w * 0.0388f
        if (bestSpan > hpRef) hpRef = bestSpan.toFloat()
        return (bestSpan / hpRef).coerceIn(0f, 1f)
    }
}
