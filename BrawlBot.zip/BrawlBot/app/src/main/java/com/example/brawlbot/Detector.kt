package com.example.brawlbot

import java.nio.ByteBuffer

/** Что бот решил сделать. dx, dy — направление движения (-1..1). */
data class BotAction(
    val dx: Float,
    val dy: Float,
    val attack: Boolean,
    val superBtn: Boolean = false,
    val gadget: Boolean = false,
    val count: Int = 0,      // красных пикселей (для отладки)
    val enemies: Int = 0,    // сколько врагов видно
    val hp: Int = 100,       // своё здоровье, %
    val mode: String = "",   // что делает бот (для уведомления)
    val aim: Boolean = false,  // выстрел с ручным прицелом
    val aimDx: Float = 0f,     // направление прицела
    val aimDy: Float = 0f
)

/**
 * Бот на правилах:
 *  - ищет врагов по красным пятнам (перчатки, кольцо под врагом), группирует их и выбирает ближайшего;
 *  - читает своё здоровье по зелёной полоске над игроком (игрок = центр экрана);
 *  - уклоняется: ходит боком вокруг врага, а при получении урона резко меняет направление;
 *  - обходит препятствия: если экран не меняется, хотя бот идёт, — сворачивает в сторону;
 *  - при низком здоровье отступает; суперудар и гаджет — когда рядом несколько врагов.
 *
 * Чтобы заменить на нейросеть: подключите TensorFlow Lite и верните BotAction из модели.
 */
object Detector {

    private const val CELL = 8
    private const val MIN_CELL = 3
    private const val MIN_BLOB = 3
    private const val FP_W = 40
    private const val FP_H = 24

    // --- пороги, которые можно подстроить ---
    private const val LOW_HP = 0.35f          // ниже этого — отступаем
    private const val STUCK_DIFF = 1.5f       // меньше — экран «не меняется»
    private const val STUCK_FRAMES = 5        // сколько кадров подряд = застрял
    private const val FIGHT_DIST = 0.25f      // дистанция боя (доля высоты экрана)
    private const val SKILL_COOLDOWN = 5000L  // пауза между суперударом/гаджетом, мс
    private const val Y_SCALE = 0.815f        // камера «сплющивает» мир по вертикали (измерено по кольцу дальности)
    private const val FIRE_INTERVAL = 700L    // пауза между прицельными выстрелами, мс
    private const val KICK_INTERVAL = 900L    // пауза между ударами по воротам, мс

    private var prevFp: IntArray? = null
    private var prevHp = 1f
    private var hpRef = 0f
    private var strafeDir = 1
    private var strafeFlipAt = 0L
    private var dodgeUntil = 0L
    private var stuckCount = 0
    private var unstuckUntil = 0L
    private var unstuckDx = 0f
    private var unstuckDy = 0f
    private var lastDx = 0f
    private var lastDy = 0f
    private var lastSuper = 0L
    private var trackX = 0f
    private var trackY = 0f
    private var trackT = 0L
    private var trackValid = false
    private var velX = 0f
    private var velY = 0f
    private var stillFrames = 0
    private var lastShot = 0L
    private var lastKick = 0L
    private var lastTgtX = 0f
    private var lastTgtY = 0f
    private var lastTgtT = 0L
    private var lastTgtDist = 0f
    private var pickDx = 0f
    private var pickDy = 0f
    private var pickupUntil = 0L
    private var lastGadget = 0L
    private val rnd = java.util.Random()

    fun analyze(
        buf: ByteBuffer, w: Int, h: Int, rowStride: Int, pixelStride: Int, now: Long
    ): BotAction {

        // ---------- 1. Красные пятна -> сетка ----------
        val gw = w / CELL + 1
        val gh = h / CELL + 1
        val grid = IntArray(gw * gh)
        val yel = IntArray(gw * gh)   // жёлтые точки (мяч)
        val ban = IntArray(gw * gh)   // красный навес ворот (верх экрана)
        val ballMode = Settings.ballMode
        val showdown = Settings.showdownMode
        val gas = IntArray(gw * gh)   // бледно-зелёные облака газа
        val uiRx = (w * 0.72f).toInt()  // зоны кнопок управления — не считаем
        val uiBy = (h * 0.60f).toInt()
        val uiLx = (w * 0.25f).toInt()
        var total = 0
        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                val i = y * rowStride + x * pixelStride
                val r = buf.get(i).toInt() and 0xFF
                val g = buf.get(i + 1).toInt() and 0xFF
                val b = buf.get(i + 2).toInt() and 0xFF
                if (r > 200 && g < 70 && b < 70) {
                    grid[(y / CELL) * gw + (x / CELL)]++
                    total++
                } else if (ballMode) {
                    if (r > 220 && g > 180 && b < 110 && r - b > 130) {
                        yel[(y / CELL) * gw + (x / CELL)]++
                    } else if (y < h * 0.45f && r > 150 && g < 95 && b < 95 && r - g > 85) {
                        ban[(y / CELL) * gw + (x / CELL)]++
                    }
                }
                if (showdown && g > 215 && r in 120..205 && b in 80..165 &&
                    g - r > 40 && g - b > 70 &&
                    !((x > uiRx && y > uiBy) || (x < uiLx && y > uiBy))) {
                    gas[(y / CELL) * gw + (x / CELL)]++
                }
                x += 2
            }
            y += 2
        }

        // ---------- 2. Пятна -> группы -> враги ----------
        val visited = BooleanArray(gw * gh)
        val stack = IntArray(gw * gh)
        val groups = ArrayList<FloatArray>() // [sumX, sumY, n]
        val mergeR = h * 0.14f
        for (start in grid.indices) {
            if (visited[start] || grid[start] < MIN_CELL) continue
            var sp = 0
            stack[sp++] = start
            visited[start] = true
            var sx = 0L
            var sy = 0L
            var cells = 0
            while (sp > 0) {
                val c = stack[--sp]
                val cx = c % gw
                val cy = c / gw
                sx += cx; sy += cy; cells++
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = cx + dx
                    val ny = cy + dy
                    if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue
                    val ni = ny * gw + nx
                    if (!visited[ni] && grid[ni] >= MIN_CELL) {
                        visited[ni] = true
                        stack[sp++] = ni
                    }
                }
            }
            if (cells < MIN_BLOB) continue
            val bx = (sx.toFloat() / cells + 0.5f) * CELL
            val by = (sy.toFloat() / cells + 0.5f) * CELL
            var merged = false
            for (g in groups) {
                val gx = g[0] / g[2]
                val gy = g[1] / g[2]
                if (kotlin.math.hypot(bx - gx, by - gy) < mergeR) {
                    g[0] += bx; g[1] += by; g[2] += 1f
                    merged = true
                    break
                }
            }
            if (!merged) groups.add(floatArrayOf(bx, by, 1f))
        }

        // ---------- 2a. Бравлбол: мяч (красно-жёлтый) и ворота врага (красный навес) ----------
        var ballFound = false
        var ballX = 0f
        var ballY = 0f
        var bannerFound = false
        var bannerX = 0f
        var bannerY = 0f
        if (ballMode) {
            val cand = BooleanArray(gw * gh)
            val score = IntArray(gw * gh)
            for (cy in 0 until gh) for (cx in 0 until gw) {
                var rs = 0
                var ys = 0
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = cx + dx
                    val ny = cy + dy
                    if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue
                    rs += grid[ny * gw + nx]
                    ys += yel[ny * gw + nx]
                }
                if (rs >= 6 && ys >= 6) { cand[cy * gw + cx] = true; score[cy * gw + cx] = rs + ys }
            }
            val vis2 = BooleanArray(gw * gh)
            var bestW = 0
            for (s in cand.indices) {
                if (!cand[s] || vis2[s]) continue
                var sp = 0
                stack[sp++] = s
                vis2[s] = true
                var sxw = 0f
                var syw = 0f
                var wt = 0
                while (sp > 0) {
                    val c = stack[--sp]
                    val cx = c % gw
                    val cy = c / gw
                    sxw += cx.toFloat() * score[c]
                    syw += cy.toFloat() * score[c]
                    wt += score[c]
                    for (dy in -1..1) for (dx in -1..1) {
                        val nx = cx + dx
                        val ny = cy + dy
                        if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue
                        val ni = ny * gw + nx
                        if (cand[ni] && !vis2[ni]) { vis2[ni] = true; stack[sp++] = ni }
                    }
                }
                if (wt > bestW) {
                    bestW = wt
                    ballX = (sxw / wt + 0.5f) * CELL
                    ballY = (syw / wt + 0.5f) * CELL
                    ballFound = true
                }
            }
            // красные панели мяча — не враг
            if (ballFound) {
                groups.removeAll {
                    kotlin.math.hypot(it[0] / it[2] - ballX, it[1] / it[2] - ballY) < h * 0.07f
                }
            }
            // ворота врага: длинная горизонтальная полоса красного вверху кадра
            val minRun = (w * 0.09f / CELL).toInt().coerceAtLeast(6)
            var bestRun = 0
            for (cy in 0 until gh) {
                var run = 0
                var startC = 0
                for (cx in 0..gw) {
                    val ok = cx < gw && ban[cy * gw + cx] >= 3
                    if (ok) {
                        if (run == 0) startC = cx
                        run++
                    } else {
                        if (run >= minRun && run > bestRun) {
                            bestRun = run
                            bannerFound = true
                            bannerX = (startC + run / 2f + 0.5f) * CELL
                            bannerY = (cy + 0.5f) * CELL
                        }
                        run = 0
                    }
                }
            }
        }

        val cx0 = w / 2f
        val cy0 = h / 2f
        var bestDist = Float.MAX_VALUE
        var bestX = 0f
        var bestY = 0f
        var enemiesNear = 0
        for (g in groups) {
            val ex = g[0] / g[2]
            val ey = g[1] / g[2]
            val d = kotlin.math.hypot(ex - cx0, ey - cy0)
            if (d < bestDist) { bestDist = d; bestX = ex; bestY = ey }
            if (d < h * 0.45f) enemiesNear++
        }
        val hasEnemy = groups.isNotEmpty()

        // ---------- 2c. Столкновение: газ и «куда делась цель» ----------
        var gasNear = false
        var fleeX = 0f
        var fleeY = 0f
        if (showdown) {
            val rad = h * 0.32f
            var gasCount = 0
            var fx = 0f
            var fy = 0f
            for (cy in 0 until gh) for (cx in 0 until gw) {
                val c = gas[cy * gw + cx]
                if (c == 0) continue
                val gx = (cx + 0.5f) * CELL - cx0
                val gy = (cy + 0.5f) * CELL - cy0
                val d = kotlin.math.hypot(gx, gy).coerceAtLeast(1f)
                if (d > rad) continue
                gasCount += c
                val wgt = c * (1f - d / rad)
                fx -= gx / d * wgt
                fy -= gy / d * wgt
            }
            if (gasCount >= (w * h / 4f * 0.0038f).toInt() && (fx != 0f || fy != 0f)) {
                val fl = kotlin.math.hypot(fx, fy)
                fleeX = fx / fl
                fleeY = fy / fl
                gasNear = true
            }
            // Ящик сломан или враг убит -> на его месте остаются кубки: идём туда
            if (hasEnemy) {
                lastTgtX = bestX; lastTgtY = bestY; lastTgtT = now; lastTgtDist = bestDist
            } else if (lastTgtT != 0L && now - lastTgtT > 250) {
                if (now - lastTgtT < 900 && lastTgtDist < h * 0.30f) {
                    val tx = lastTgtX - cx0
                    val ty = lastTgtY - cy0
                    val tl = kotlin.math.hypot(tx, ty).coerceAtLeast(1f)
                    pickDx = tx / tl
                    pickDy = ty / tl
                    pickupUntil = now + (tl / (h * 0.45f) * 1000f).toLong().coerceIn(300L, 1500L)
                }
                lastTgtT = 0L
            }
        }

        // ---------- 2b. Скорость ближайшего врага (считаем, только пока бот стоит) ----------
        val stillPrev = lastDx == 0f && lastDy == 0f
        if (hasEnemy) {
            if (trackValid && now - trackT < 400 &&
                kotlin.math.hypot(bestX - trackX, bestY - trackY) < h * 0.15f) {
                val dt = (now - trackT) / 1000f
                if (stillPrev && dt > 0.02f) {
                    velX = 0.6f * velX + 0.4f * (bestX - trackX) / dt
                    velY = 0.6f * velY + 0.4f * (bestY - trackY) / dt
                } else if (!stillPrev) {
                    velX *= 0.8f; velY *= 0.8f
                }
            } else {
                velX = 0f; velY = 0f
            }
            trackX = bestX; trackY = bestY; trackT = now; trackValid = true
        } else {
            trackValid = false; velX = 0f; velY = 0f
        }
        stillFrames = if (stillPrev) stillFrames + 1 else 0

        // ---------- 3. Своё здоровье ----------
        val hpRead = readHp(buf, w, h, rowStride, pixelStride)
        val hp = if (hpRead < 0f) prevHp else hpRead
        val hpDrop = prevHp - hp > 0.03f
        prevHp = hp

        // ---------- 4. «Отпечаток» кадра для определения застревания ----------
        val fp = IntArray(FP_W * FP_H)
        for (gy in 0 until FP_H) {
            val py = ((gy + 0.5f) * h / FP_H).toInt().coerceIn(0, h - 1)
            for (gx in 0 until FP_W) {
                val px = ((gx + 0.5f) * w / FP_W).toInt().coerceIn(0, w - 1)
                fp[gy * FP_W + gx] = buf.get(py * rowStride + px * pixelStride + 1).toInt() and 0xFF
            }
        }
        val prev = prevFp
        var diff = 99f
        if (prev != null) {
            var s = 0L
            for (k in fp.indices) s += kotlin.math.abs(fp[k] - prev[k])
            diff = s.toFloat() / fp.size
        }
        prevFp = fp

        val wasMoving = lastDx != 0f || lastDy != 0f
        if (wasMoving && diff < STUCK_DIFF && now >= unstuckUntil) stuckCount++ else stuckCount = 0
        if (stuckCount >= STUCK_FRAMES) {
            stuckCount = 0
            unstuckUntil = now + 1000
            val sign = if (rnd.nextBoolean()) 1f else -1f
            unstuckDx = -lastDy * sign
            unstuckDy = lastDx * sign
            if (unstuckDx == 0f && unstuckDy == 0f) unstuckDx = sign
        }

        // ---------- 5. Уклонение: смена стороны ----------
        if (now >= strafeFlipAt) {
            strafeDir = -strafeDir
            strafeFlipAt = now + 700 + rnd.nextInt(500)
        }
        if (hpDrop) {
            strafeDir = -strafeDir
            dodgeUntil = now + 500
            strafeFlipAt = now + 1200
        }

        // ---------- 6. Решение ----------
        var dx = 0f
        var dy = 0f
        var attack = false
        var mode: String

        val vx = bestX - cx0
        val vy = bestY - cy0
        val dist = bestDist.coerceAtLeast(1f)
        val ux = if (hasEnemy) vx / dist else 0f
        val uy = if (hasEnemy) vy / dist else 0f
        val px = -uy * strafeDir // перпендикуляр (бок)
        val py = ux * strafeDir

        if (now < unstuckUntil) {
            dx = unstuckDx; dy = unstuckDy; attack = hasEnemy; mode = "обход препятствия"
        } else if (hasEnemy && hp < LOW_HP) {
            dx = -ux; dy = -uy; attack = true; mode = "отступление"
        } else if (!hasEnemy && hp < LOW_HP) {
            mode = "отдых"
        } else if (!hasEnemy) {
            dy = -1f; mode = "поиск"
        } else if (now < dodgeUntil) {
            dx = px; dy = py; attack = true; mode = "уклонение"
        } else if (dist >= h * FIGHT_DIST) {
            dx = ux + px * 0.35f; dy = uy + py * 0.35f; attack = true; mode = "сближение"
        } else {
            dx = px * 0.9f; dy = py * 0.9f
            if (dist < h * 0.12f) { dx -= ux * 0.6f; dy -= uy * 0.6f }
            attack = true; mode = "бой"
        }

        val len = kotlin.math.hypot(dx, dy)
        if (len > 1f) { dx /= len; dy /= len }

        // ---------- 6b. Ручной прицел с упреждением ----------
        var aim = false
        var aimDx = 0f
        var aimDy = 0f
        if (Settings.aimMode) {
            attack = false // вместо тапа стреляем только прицельно
            if (hasEnemy && now >= unstuckUntil && hp >= LOW_HP) {
                val pxw = vx
                val pyw = vy / Y_SCALE // перевод в «мировые» координаты
                if (kotlin.math.hypot(pxw, pyw) <= h * Settings.range) {
                    if (now - lastShot > FIRE_INTERVAL) {
                        dx = 0f; dy = 0f
                        mode = "прицеливание"
                        if (stillFrames >= 2) {
                            val d = interceptDir(pxw, pyw, velX, velY / Y_SCALE, Settings.projSpeed * h)
                            aim = true; aimDx = d[0]; aimDy = d[1]
                            lastShot = now
                            mode = "выстрел с упреждением"
                        }
                    }
                }
            }
        }

        // ---------- 6c. Бравлбол ----------
        if (ballMode && now >= unstuckUntil) {
            val carrying = ballFound && kotlin.math.hypot(ballX - cx0, ballY - cy0) < h * 0.09f
            var gdx = 0f
            var gdy = -1f
            var gd = Float.MAX_VALUE
            if (bannerFound) {
                val gx = bannerX - cx0
                val gy = (bannerY - cy0) / Y_SCALE
                gd = kotlin.math.hypot(gx, gy).coerceAtLeast(1f)
                gdx = gx / gd
                gdy = gy / gd
            }
            if (bannerFound && gd <= h * Settings.kickRange &&
                (carrying || !ballFound) && now - lastKick > KICK_INTERVAL) {
                // удар по воротам (если мяча у нас нет — просто выстрел в сторону ворот)
                aim = true; aimDx = gdx; aimDy = gdy
                lastKick = now
                attack = false
                mode = "удар по воротам"
            } else if (ballFound && !carrying) {
                if (!(hasEnemy && dist < h * 0.18f)) {
                    val bvx = ballX - cx0
                    val bvy = (ballY - cy0) / Y_SCALE
                    val bd = kotlin.math.hypot(bvx, bvy).coerceAtLeast(1f)
                    dx = bvx / bd; dy = bvy / bd
                    mode = "к мячу"
                }
            } else if (carrying) {
                dx = gdx; dy = gdy
                mode = "несу мяч"
            } else if (bannerFound && !(hasEnemy && dist < h * FIGHT_DIST)) {
                dx = gdx; dy = gdy
                mode = "к воротам"
            }
            if (carrying) attack = false // тап по атаке выбил бы мяч
        }

        // ---------- 6d. Столкновение ----------
        if (showdown) {
            if (gasNear) {
                dx = fleeX; dy = fleeY
                mode = "бегу от газа"
            } else if (now < pickupUntil && hp >= LOW_HP && !(hasEnemy && dist < h * 0.18f)) {
                dx = pickDx; dy = pickDy
                mode = "собираю кубки"
            }
        }

        // ---------- 7. Суперудар и гаджет ----------
        var sup = false
        var gad = false
        if (enemiesNear >= 2 && now - lastSuper > SKILL_COOLDOWN) {
            sup = true; lastSuper = now
        }
        if ((enemiesNear >= 2 || (enemiesNear >= 1 && hp < 0.6f)) && now - lastGadget > SKILL_COOLDOWN) {
            gad = true; lastGadget = now
        }

        lastDx = dx
        lastDy = dy
        return BotAction(
            dx, dy, attack, sup, gad,
            count = total, enemies = groups.size, hp = (hp * 100).toInt(), mode = mode,
            aim = aim, aimDx = aimDx, aimDy = aimDy
        )
    }

    /**
     * Куда целиться, чтобы снаряд (скорость s) попал в цель, которая сейчас в точке (px,py)
     * и движется со скоростью (vx,vy). Возвращает единичный вектор направления.
     */
    private fun interceptDir(px: Float, py: Float, vx: Float, vy: Float, s: Float): FloatArray {
        val a = vx * vx + vy * vy - s * s
        val b = 2f * (px * vx + py * vy)
        val c = px * px + py * py
        var t = 0f
        if (kotlin.math.abs(a) < 1e-3f) {
            if (kotlin.math.abs(b) > 1e-3f) t = -c / b
        } else {
            val disc = b * b - 4f * a * c
            if (disc >= 0f) {
                val sq = kotlin.math.sqrt(disc)
                val t1 = (-b - sq) / (2f * a)
                val t2 = (-b + sq) / (2f * a)
                t = listOf(t1, t2).filter { it > 0f }.minOrNull() ?: 0f
            }
        }
        t = t.coerceIn(0f, 1.2f)
        val ax = px + vx * t
        val ay = py + vy * t
        val len = kotlin.math.hypot(ax, ay).coerceAtLeast(1f)
        return floatArrayOf(ax / len, ay / len)
    }

    /** Своё здоровье 0..1 по зелёной полоске над игроком, либо -1 если не нашли. */
    private fun readHp(buf: ByteBuffer, w: Int, h: Int, rowStride: Int, pixelStride: Int): Float {
        val cx = w / 2
        val half = (w * 0.035f).toInt().coerceAtLeast(6)
        val yA = (h * 0.40f).toInt()
        val yB = (h * 0.435f).toInt()
        var bestCount = 0
        var bestSpan = 0
        for (y in yA..yB) {
            var cnt = 0
            var minX = Int.MAX_VALUE
            var maxX = -1
            for (x in (cx - half)..(cx + half)) {
                if (x < 0 || x >= w || y < 0 || y >= h) continue
                val i = y * rowStride + x * pixelStride
                val r = buf.get(i).toInt() and 0xFF
                val g = buf.get(i + 1).toInt() and 0xFF
                val b = buf.get(i + 2).toInt() and 0xFF
                if (g > 170 && g - r > 40 && g - b > 50) {
                    cnt++
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                }
            }
            if (cnt > bestCount) { bestCount = cnt; bestSpan = maxX - minX + 1 }
        }
        if (bestCount < 4) return -1f
        if (hpRef == 0f) hpRef = w * 0.0388f
        if (bestSpan > hpRef) hpRef = bestSpan.toFloat()
        return (bestSpan / hpRef).coerceIn(0f, 1f)
    }
}
