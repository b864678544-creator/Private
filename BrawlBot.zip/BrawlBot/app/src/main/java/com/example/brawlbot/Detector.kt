package com.example.brawlbot

import java.nio.ByteBuffer

/** Что бот решил сделать. dx, dy — направление движения (-1..1). */
data class BotAction(val dx: Float, val dy: Float, val attack: Boolean)

/**
 * Простой детектор на правилах: ищет красные полоски здоровья врагов.
 * Игрок считается находящимся примерно в центре экрана.
 *
 * Чтобы заменить на нейросеть: подключите TensorFlow Lite и
 * верните BotAction из модели вместо этой функции.
 */
object Detector {

    fun analyze(buf: ByteBuffer, w: Int, h: Int, rowStride: Int, pixelStride: Int): BotAction {
        var sumX = 0L
        var sumY = 0L
        var count = 0
        val step = 2

        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                val i = y * rowStride + x * pixelStride
                val r = buf.get(i).toInt() and 0xFF
                val g = buf.get(i + 1).toInt() and 0xFF
                val b = buf.get(i + 2).toInt() and 0xFF
                // «красный» цвет полоски врага (подберите пороги под свой экран)
                if (r > 200 && g < 70 && b < 70) {
                    sumX += x; sumY += y; count++
                }
                x += step
            }
            y += step
        }

        if (count < 15) {
            // Врагов не видно — идём вперёд (вверх)
            return BotAction(dx = 0f, dy = -1f, attack = false)
        }

        val ex = sumX.toFloat() / count
        val ey = sumY.toFloat() / count
        val vx = ex - w / 2f
        val vy = ey - h / 2f
        val dist = kotlin.math.hypot(vx, vy).coerceAtLeast(1f)

        val near = dist < h * 0.35f
        // Если враг близко — стоим и стреляем, иначе сближаемся
        return BotAction(
            dx = if (near) 0f else vx / dist,
            dy = if (near) 0f else vy / dist,
            attack = true
        )
    }
}
