package com.example.brawlbot

import java.nio.ByteBuffer

/** Что бот решил сделать. dx, dy — направление движения (-1..1). */
data class BotAction(val dx: Float, val dy: Float, val attack: Boolean, val count: Int = 0)

/**
 * Детектор на правилах: ищет красные пятна (перчатки/кольцо врага),
 * группирует их в отдельных врагов и выбирает ближайшего к игроку.
 * Игрок считается находящимся в центре экрана.
 *
 * Чтобы заменить на нейросеть: подключите TensorFlow Lite и
 * верните BotAction из модели вместо этой функции.
 */
object Detector {

    private const val CELL = 8      // размер ячейки сетки (пикселей уменьшенного кадра)
    private const val MIN_CELL = 3  // минимум красных точек в ячейке, чтобы считать её «врагом»
    private const val MIN_BLOB = 3  // минимум ячеек в одном враге

    fun analyze(buf: ByteBuffer, w: Int, h: Int, rowStride: Int, pixelStride: Int): BotAction {
        val gw = w / CELL + 1
        val gh = h / CELL + 1
        val grid = IntArray(gw * gh)
        var total = 0

        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                val i = y * rowStride + x * pixelStride
                val r = buf.get(i).toInt() and 0xFF
                val g = buf.get(i + 1).toInt() and 0xFF
                val b = buf.get(i + 2).toInt() and 0xFF
                if (r > 200 && g < 70 && b < 70) {
                    grid[(y / CELL) * gw + (x / CELL)]++
                    total++
                }
                x += 2
            }
            y += 2
        }

        // Ищем связные группы ячеек (отдельные враги)
        val visited = BooleanArray(gw * gh)
        val stack = IntArray(gw * gh)
        val cx0 = w / 2f
        val cy0 = h / 2f
        var bestDist = Float.MAX_VALUE
        var bestX = 0f
        var bestY = 0f
        var found = false

        for (start in grid.indices) {
            if (visited[start] || grid[start] < MIN_CELL) continue
            var sp = 0
            stack[sp++] = start
            visited[start] = true
            var sx = 0L
            var sy = 0L
            var cells = 0
            while (sp > 0) {
                val c = stack[--sp]
                val cx = c % gw
                val cy = c / gw
                sx += cx; sy += cy; cells++
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = cx + dx
                    val ny = cy + dy
                    if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue
                    val ni = ny * gw + nx
                    if (!visited[ni] && grid[ni] >= MIN_CELL) {
                        visited[ni] = true
                        stack[sp++] = ni
                    }
                }
            }
            if (cells < MIN_BLOB) continue
            val ex = (sx.toFloat() / cells + 0.5f) * CELL
            val ey = (sy.toFloat() / cells + 0.5f) * CELL
            val d = kotlin.math.hypot(ex - cx0, ey - cy0)
            if (d < bestDist) { bestDist = d; bestX = ex; bestY = ey; found = true }
        }

        if (!found) {
            // Врагов не видно — идём вперёд (вверх)
            return BotAction(dx = 0f, dy = -1f, attack = false, count = total)
        }

        val vx = bestX - cx0
        val vy = bestY - cy0
        val dist = bestDist.coerceAtLeast(1f)
        val near = dist < h * 0.25f
        // Рядом — стоим и стреляем (тап по атаке сам целится в ближайшего), далеко — сближаемся
        return BotAction(
            dx = if (near) 0f else vx / dist,
            dy = if (near) 0f else vy / dist,
            attack = true,
            count = total
        )
    }
}
